function [Normaldepth] = NormalDepthCanal(Q, b, z, n, S)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This funcrion is reproduced form the paper "MATLAB Programming Solution
% For Critical And Normal Depth In Trapezoidal Channels" written by 
% Harinarayan Tiwari,Pritikana Das and Anish Kumar Bharti.
% Original paper can be retreived from the following link:
% https://www.ijert.org/matlab-programming-solution-for-critical-and-normal-depth-in-trapezoidal-channels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input Parameters for Trapezoidal cross section (rectangular or V are
% obtained by using side slope = 0 and bottom width = 0, respectively)
%Q= input('discharge in cumec=');
%b= input('bottom width of channel in m=');
%z= input('side slope H to V=');
%n= input('manning coefficient=');
%S= input('Longitudinal slope=');
yinitial=0.01; %Initial Guess to start the iterations
% Normal Depth Calculation
 yn(1)=yinitial;
 in=1;
 dyn(1)=1e-2;
 while (abs(dyn(in))>1e-4)
 An(in)=b*yn(in)+z*(yn(in))^2;
 Tn(in)=b+2*z*yn(in);
 Pn(in)=b+2*(z^2+1)^(0.50)*yn(in);
 Rn(in)=An(in)/(Pn(in));
 Dn(in)=An(in)/(b+2*z*yn(in));
 fn(in)=sqrt(S)*An(in)*Rn(in)^(2/3)*n^(-1)-Q;
 ffn(in)=(sqrt(S)*n^(-1))*((Rn(in)^(2/3)*Tn(in))+(Tn(in)/Pn(in))-((2*yn(in)*Rn(in))/Pn(in)));
 yn(in+1)=yn(in)-fn(in)/ffn(in);
 dyn(in+1)=-fn(in)/ffn(in);
 in=in+1;
 end
 Normaldepth=yn(in);