function R = pointWithinLine(P1, P2, Q, EndPoints)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function determines if point Q lies on the 2D line defined by points
% P1 and P2, two end points of a line segement
% Function considers line in all directions, rounding errors and if the 4th
% input is used, Q must be element of the line between P1 and P2 
% Function was created from an answer by Jan to the question from Matlab
% Central
% Link: https://nl.mathworks.com/matlabcentral/answers/351581-points-lying-within-line
%
% Is point Q=[x3,y3] on line through P1=[x1,y1] and P2=[x2,y2]
% If three input arguments are put in it only calculates if point is on line
% If four input arguments are put in (last one can be 1) it also calculates if point Q is on the line P1 P2 or not
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Normal along the line:
P12 = P2 - P1;
L12 = sqrt(P12 * P12');
N   = P12 / L12;
% Line from P1 to Q:
PQ = Q - P1;
% Norm of distance vector: LPQ = N x PQ
Dist = abs(N(1) * PQ(2) - N(2) * PQ(1));
% Consider rounding errors:
Limit = 10 * eps(max(abs(cat(1, P1(:), P2(:), Q(:)))));
R     = (Dist < Limit);
% Consider end points if any 4th input is used:
if R && nargin == 4
  % Projection of the vector from P1 to Q on the line:
  L = PQ * N.';  % DOT product
  R = (L > 0.0 && L < L12);
end