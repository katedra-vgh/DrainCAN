function [Xp, Yp] = extend2Dline(x1, y1, x2, y2, L)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function extends line in 2D space beyond its starting point (x1 y1)
% for selected lenght L
% Line is defined with two points - start (x1 y1) and aen (x2 y2)
% Slope and intercept of the line equation are calculated 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PointLR = [x1 y1];
PointDR = [x2 y2];

% double-check for primitive solutions (vertical or horizontal lines)
if x1 == x2 && y1 ~= y2
    % vertical line
    dx = 0;
    dy = L;
elseif y1 == y2 && x1 ~= x2
    % horizontal line
    dx = L;
    dy = 0;
elseif x1 == x2 && y1 == y2
    % first and last point are the same
    msgbox('First and last point are the same!', 'Notification');
    dx = 0;
    dy = 0;
else
    m = (PointDR(1,2)-PointLR(1,2))/(PointDR(1,1)-PointLR(1,1)); % slope
    dx = L / sqrt(1+m^2); % distance on X-axis
    dy = dx*abs(m); % distance on Y-axis
end


%% CALCULATION OF POINT POSITION VIA QUADRANTS

% determining the quadrant in which PP is positioned
if PointLR(1,1) <= PointDR(1,1) && PointLR(1,2) <= PointDR(1,2) % line PP is in quadrant I 
    Xp = x1 + dx;
    Yp = y1 + dy;
elseif PointLR(1,1) >= PointDR(1,1) && PointLR(1,2) <= PointDR(1,2) % line PP is in quadrant II
    Xp = x1 - dx;
    Yp = y1 + dy;  
elseif PointLR(1,1) >= PointDR(1,1) && PointLR(1,2) >= PointDR(1,2) % line PP is in quadrant III
    Xp = x1 - dx;
    Yp = y1 - dy;
elseif PointLR(1,1) <= PointDR(1,1) && PointLR(1,2) >= PointDR(1,2) % line PP is in quadrant IV
    Xp = x1 + dx;
    Yp = y1 - dy;
end