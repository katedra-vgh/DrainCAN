function DrainCAN_11
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function generates geometry and flow files for HEC-RAS steady stafe
% flow model from structured input files prepared in .dxf and .xls format.
% Function accepts input data from three files:
% (1) DrainageCanalNetwork.dxf - drainage canal network created as 
% polylines in Drawing Interchange Format format file with locations of
% computational cross-sections
% (2) CanalGeometryAndInflow.xls - geometry of each canal assigned in cells
% of structured .xls file, together with inflow for each cross-section
% (3) Terrain.dxf - terrain topography created as 3D points, LW polylines
% or 3D polylines
% Output files (.sdf and .f01) are saved in the same location where input
% files are located 
% Detailed description of the function can be found in the Paper "DrainCAN
% � MATLAB function for generation of HEC-RAS compatible drainage canal
% network model"
% Working example can be retreived from MDPI database
%
% history:
% version 1.0: initial release
% version 1.1: minor adjustments in order to achieve compatibility with Octave
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
[PathStrM, ~] = fileparts(mfilename('fullpath')); % path of this .m file
folders = strsplit(PathStrM,'\');
drive=[folders{1} '\']; % computer's drive

%% INPUT DATA
              
% Load .dxf file DrainageCanalNetwork
    [dxfFileNameDCN, dxfPathNameDCN] = uigetfile('*.dxf','Select .dxf file with the canal network (DrainageCanalNetwork.dxf)', drive);
    rawDxf2 = dxf2coord_20(dxfFileNameDCN, dxfPathNameDCN);
    rawDxfReach = num2cell(rawDxf2{7});
    % Canals are drawn as continuous polylines starting from the most upstream point
    % towards the canal outlet
    % Cross-sections are drawn as continuous polylines from left bank to the
    % right, associated with canals by common layer names

lwpolylayers = rawDxf2{8};
[m, n] = size(rawDxf2{7});
for i=1:m
    layerOrdinalNr = rawDxfReach{i,1};
    [stream, remain1] = strtok(lwpolylayers{layerOrdinalNr,1},'_');
    rawDxfReach{i,n+1} = stream;
    [reach, remain2] = strtok(remain1,'_');
    rawDxfReach{i,n+2} = reach;
    [station] = strtok(remain2,'_');
    rawDxfReach{i,n+3} = station;
end

% Find data ekstent
    Emin = min(cell2mat(rawDxfReach(:,2)));
    Emax = max(cell2mat(rawDxfReach(:,2)));
    Nmin = min(cell2mat(rawDxfReach(:,3)));
    Nmax = max(cell2mat(rawDxfReach(:,3)));
    Extent = [Emin-(0.1*abs(Emax - Emin)) Nmin-(0.1*abs(Nmax - Nmin)) Emax+(0.1*abs(Emax - Emin)) Nmax+(0.1*abs(Nmax - Nmin))];

% create output path
    sdfPathOut = [dxfPathNameDCN 'HEC-geometry.sdf'];
    flowPathOut = [dxfPathNameDCN 'HEC-flow.f01'];

clear m n i remain1 remain2 remain3 stream reach station layerOrdinalNr rawDxf2 dxfFileNameDCN PathStrM drive folders
clear Emin Emax Nmin Nmax
       
% constants
    tolerance = 5; % tolerance for canal proximity at junctions
    streamName = 'canal';

%% PROCESS GEOMETRY DATA

% read in the canals from .dxf polylines
% check which drawing entities are in layer with extension "Reach"
    IDreach = strcmp(rawDxfReach(:,7),'Reach');
	IDcanals = rawDxfReach(IDreach,6); 
% Collect drawing entity data
    if all(IDreach==0)
        % Reach layer does not exist - terminate code
        msgbox('POLYLINES that represent the Reach do not exist in the DrainageCanalNetwork file (or the layers are incorrectly named). Terminating function!', 'Notification');
        return
    else
        canalsReach = unique(IDcanals);
        % check if canal DC-I-1 exists
        if any(ismember(canalsReach,'DC-I-1'))==1
        else
            msgbox('DC-I-1 does not exist in the DrainageCanalNetwork file. Terminating function!', 'Notification');
            return
        end
    end

% Load .xls file CanalGeometryAndInflow
    [xlsFileNameCGI, xlsPathNameCGI] = uigetfile({'*.xlsx';'*.xls'},'Select .xlsx file with cross-sectional geometry (CanalGeometryAndInflow.xls)', dxfPathNameDCN);
    xlsFullPath = [xlsPathNameCGI xlsFileNameCGI];
    %[~,xlsSheets] = xlsfinfo(xlsFullPath); %INMATLAB
    xlsSheets_DELETE = load('C:\Octave\xlsSheets');
    xlsSheets=xlsSheets_DELETE.xlsSheets;
    clear xlsPathNameCGI xlsFileNameCGI
    
% process CGI data - Primary, Secondary and Tertiary canals
    for i=1:size(canalsReach,1)
        % check the canal names
            canalName = canalsReach{i};
            % canalsReachLayer = regexp(canalName,'-','split'); %INMATLAB
            canalsReachLayer = strsplit(canalName,'-');
            if strcmp(canalsReachLayer{1},'DC')==1 && strcmp(canalsReachLayer{2}(1),'I')==1 && isnan(str2double(canalsReachLayer{3}))==0
                % OK
            else
                msgbox('in the DrainageCanalNetwork file DC- canal names are not defined correctly. Terminating function!', 'Notification');
                return
            end
        % check if the worksheet exists 
            if ismember(canalName,xlsSheets)==1
                % OK
                % [~,~,raw] = xlsread(xlsFullPath,canalName,'A1:B1000'); INMATLAB
                raw_DELETE = load(['C:\Octave\RAW_' mat2str(i)]);
                raw=raw_DELETE.raw;
                clear raw_DELETE
            else
                msgbox(['Worksheet ' canalName ' does not exist in CanalGeometryAndInflow file. Terminating function!'], 'Notification');
                return
            end
        % copy data in MATLAB structure
            Model.([streamName '_' mat2str(i)]).name = canalName;
        % XS geometry
            for j=2:6
                [valueIN] = stringDoubleCheck(mat2str(raw{j,2}),canalName);
                    if j==2, Model.([streamName '_' mat2str(i)]).invert = valueIN;
                    elseif j==3, Model.([streamName '_' mat2str(i)]).width_btm = valueIN;
                    elseif j==4, Model.([streamName '_' mat2str(i)]).slope_canal = valueIN;
                    elseif j==5, Model.([streamName '_' mat2str(i)]).slope_bank = valueIN;
                    elseif j==6, Model.([streamName '_' mat2str(i)]).manning = valueIN;
                    end
                clear valueIN
            end
        % runoff
            for k=7:size(raw,1)
                if isnan(raw{k,2})==1
                    % NaN
                elseif isnumeric(raw{k,1})==1
                    msgbox(['In CanalGeometryAndInflow worksheet ' canalName ' cross-section station is entered as a number. Terminating function!'], 'Notification');
                    return
                else
                        %stationRaw = regexp(raw{k,1},'+','split'); %INMATLAB
                        stationRaw = strsplit(raw{k,1},'+');
                        if size(stationRaw,2)==2
                            % OK
                                stationXS = [stationRaw{1} stationRaw{2}];
                            % check if station exists in DCN file
                                XSlayer = [streamName '_' canalName '_' raw{k,1}];
                                if ismember(XSlayer,lwpolylayers)==1
                                    % OK
                                    [valueINstation] = stringDoubleCheck(stationXS, XSlayer);
                                    [valueINinflow] = stringDoubleCheck(mat2str(raw{k,2}), XSlayer);
                                    Model.([streamName '_' mat2str(i)]).inflow{k-6,1} = raw{k,1};
                                    Model.([streamName '_' mat2str(i)]).inflow{k-6,2} = valueINstation;
                                    Model.([streamName '_' mat2str(i)]).inflow{k-6,3} = valueINinflow;
                                else
                                    % There is no sheet that matches a canal in CAD, leave code
                                    msgbox(['In .CAD file there is no layer ' XSlayer ' which is entered in .XLS fileu. Terminating function.'], 'Notification');
                                    return % leave code
                                end
                        clear stationXS XSlayer valueINstation valueINinflow
                        else
                            % Layer names aren't defined correctly, leave code
                            msgbox(['In CanalGeometryAndInflow worksheet ' canalName ' cross-section stations are not entered correctly. Terminating function!'], 'Notification');
                            return
                        end  
                clear stationRaw 
                end
            end
    % calculate normal depth
        Qk = max(cell2mat(Model.([streamName '_' mat2str(i)]).inflow(:,3)));
        bk = Model.([streamName '_' mat2str(i)]).width_btm;
        zk = Model.([streamName '_' mat2str(i)]).slope_bank;
        nk = Model.([streamName '_' mat2str(i)]).manning;
        Sk = Model.([streamName '_' mat2str(i)]).slope_canal;
            Model.([streamName '_' mat2str(i)]).normalDepth = NormalDepthCanal(Qk, bk, zk, nk, Sk);
           
    clear canalName canalsReachLayer raw j k Qk bk zk nk Sk
    end
    clear IDreach IDcanals lwpolylayers canalsReach  

% process CGI data - lateral canal (DC-IV)
    if ismember('DC-IV',xlsSheets)==1
            %[~,~,raw] = xlsread(xlsFullPath,'DC-IV','A1:B3'); %INMATLAB
            raw_DELETE = load('C:\Octave\RAW_IV'); %INMATLAB
            raw=raw_DELETE.raw;
            clear raw_DELETE
            [LatCanalDepth] = stringDoubleCheck(mat2str(raw{2,2}), 'DC-IV');
            [LatCanalFlowDepth] = stringDoubleCheck(mat2str(raw{3,2}), 'DC-IV');
                Model.([streamName '_' mat2str(i+1)]).name = 'DC-IV-1';
                Model.([streamName '_' mat2str(i+1)]).depth = LatCanalDepth-LatCanalFlowDepth;
                depthLateral = LatCanalDepth-LatCanalFlowDepth;
    else
            msgbox('Worksheet with lateral canal does not exist. Terminating function!', 'Notification');
            return
    end
    clear i xlsFullPath xlsSheets raw LatCanalDepth LatCanalFlowDepth
            
%% PROCESS CROSS-SECTION GEOMETRY

% Load .dxf file Terrain
    [dxfFileNameTerrain, dxfPathNameTerrain] = uigetfile('*.dxf','Select .dxf file with land topography (Terrain.dxf)', dxfPathNameDCN);
    rawDxf2 = dxf2coord_20(dxfFileNameTerrain, dxfPathNameTerrain);
        if isnan(rawDxf2{1})==1
            % No points in Terrain file
            rawDxfTerrainPTS = [NaN NaN NaN];
        else
            rawDxfTerrainPTS = rawDxf2{1}(:,2:4);
        end
        if isnan(rawDxf2{5})==1
            % No lines in Terrain file
            rawDxfTerrainLN = [NaN NaN NaN];
        else
            rawDxfTerrainLN = rawDxf2{5}(:,2:4);
        end
        if isnan(rawDxf2{7})==1
            % No polylines in Terrain file
            rawDxfTerrainLWP = [NaN NaN NaN];
        else
            rawDxfTerrainLWP = rawDxf2{7}(:,2:4);
        end
        if isnan(rawDxf2{9})==1
            % No 3Dpolylines in Terrain file
            rawDxfTerrain3DP = [NaN NaN NaN];
        else
            rawDxfTerrain3DP = rawDxf2{9}(:,2:4);
        end
        rawDxfTerrainXYZ = vertcat(rawDxfTerrainPTS,rawDxfTerrainLN, rawDxfTerrainLWP,rawDxfTerrain3DP);
            rawDxfTerrainX = rawDxfTerrainXYZ(:,1);
            rawDxfTerrainY = rawDxfTerrainXYZ(:,2);
            rawDxfTerrainZ = rawDxfTerrainXYZ(:,3);
    clear dxfFileNameTerrain dxfPathNameTerrain rawDxf2 dxfPathNameDCN rawDxfTerrainPTS rawDxfTerrainLN rawDxfTerrainLWP rawDxfTerrain3DP rawDxfTerrainXYZ
% start XS counter
    numberOFcrosssections = 0;

%for i=1:size(fields(Model),1) % INMATLAB
for i=1:size(fieldnames(Model),1)
% work canals one at a time
    activeCanal = Model.([streamName '_' mat2str(i)]).name;

if strcmp(activeCanal,'DC-IV-1')==1
    % lateral canal
else
% check which rows belong to the active canal layer   
    IDcanal = strcmp(rawDxfReach(:,6),activeCanal);
    activeData = rawDxfReach(IDcanal,1:7);
    activeRows = rawDxfReach(IDcanal,7);
% Separate rows in which there is reach of cross-sections
	IDreach = strcmp(activeRows, 'Reach');
    IDstations = ~IDreach;      
% Quality control
    if all(IDstations == 0)
        msgbox(['In DrainageCanalNetwork file there are no polylines that represent canal cross-sections' activeCanal '. Terminating function.'], 'Notification');
        return
    else
        % OK
    end
% Collect data for reach and cross-sections
    activeReach = activeData(IDreach,1:7);
        Model.([streamName '_' mat2str(i)]).Reach = cell2mat(activeReach(:,2:3));
    activeXS = activeData(IDstations,1:7);
        XSstations = unique(activeXS(:,7));
    clear IDcanal activeData activeRows IDreach IDstations activeData
    
% Quality control
    for j=1:size(XSstations,1)
        % process station into a field name
            activeXSstation = XSstations{j};
            activeXSstation = activeXSstation(~isspace(activeXSstation)); % get rid of accidental spaces in layer name
       % check if "+" is entered as a separator between numbers
        if mean(ismember(activeXSstation,'+'))>0
            % "+" is entered as a separator, separate station
            %partsXSstation = regexp(activeXSstation,'+','split'); %INMATLAB
            partsXSstation = strsplit(activeXSstation,'+');
            % check if numbers are entered correctly (one or three digits)
            if size(partsXSstation,2)==2 && size(partsXSstation{1},2)==1 && size(partsXSstation{2},2)==3
                % stations are entered correctly, proceed
                fieldstation = [partsXSstation{1} partsXSstation{2}];
                XSstations{j,2} = fieldstation;
                XSstations{j,3} = str2double(fieldstation);
                clear fieldstation
            else
                msgbox(['Cross-sections for canal ' activeCanal ' are not entered as [km]+[m] in the layer name (DrainageCanalNetwork). Terminating function!'], 'Notification');
                return
            end
        else
            % layer name does not have "+" as a separator between km and m
            msgbox(['Cross-sections for canal ' activeCanal ' are not entered as [km]+[m] in the layer name (DrainageCanalNetwork). Terminating function!'], 'Notification');
            return
        end
        clear activeXSstation partsXSstation 
    end
    clear j
    
% Create 3D points for cross-sections   
    for j=1:size(XSstations,1)
        activeXSstation = XSstations{j,1};
        % create new field with a station
            fieldstation = XSstations{j,2};
            Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).station = str2double(fieldstation);
        % check which rows belong to active station layer
            IDstation = strcmp(activeXS(:,7),activeXSstation);
        % write cross-section endpoints data
            Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).limitsXS = cell2mat(activeXS(IDstation,2:3));
        % Find cross-section midpoint
            Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).midpointXS = mean(Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).limitsXS);
        % Find terrain elevation closest to midpoint
            deltaX = rawDxfTerrainX - Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).midpointXS(1,1);
            deltaY = rawDxfTerrainY - Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).midpointXS(1,2);
            deltaDist = sqrt(deltaX.^2+deltaY.^2);
            [~,rowMidpointXS] = min(deltaDist);
            elevationTerrainMidpointXS = rawDxfTerrainZ(rowMidpointXS,1);
            Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).terrain = elevationTerrainMidpointXS;
        clear IDstation deltaX deltaY deltaDist rowMidpointXS 
        
        % calculate canal depth
            % Find the distance from the first XS
                deltaL = Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).station;
            % invert elevation = start invert elevation + dL * I
                invertElevation = Model.([streamName '_' mat2str(i)]).invert + (Model.([streamName '_' mat2str(i)]).slope_canal * deltaL);
            % Calculate water surface elevation for each cross-section
                 %activeCanalType = regexp(activeCanal,'-','split'); %INMATLAB
                 activeCanalType = strsplit(activeCanal,'-');
                 % calculate water surface elevation in the lateral drain which connects to tertiary and secondary canals
                    if strcmp(activeCanalType{2},'II')==1 || strcmp(activeCanalType{2},'III')==1
                        % It's a secondary or tertiary canal, enter it's water surface elevation
                        if XSstations{j,3} == min(cell2mat(XSstations(:,3)))
                        % for the first cross-section, enter normal depth as Observed
                            Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).HECobserved = Model.([streamName '_' mat2str(i)]).invert + Model.([streamName '_' mat2str(i)]).normalDepth;
                        elseif XSstations{j,3} ~= max(cell2mat(XSstations(:,3)))
                            % for all other cross-sections except the last enter water surface elevation in lateral drain
                            Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).HECobserved = Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).terrain - depthLateral;
                        elseif XSstations{j,3} == max(cell2mat(XSstations(:,3))) && strcmp(activeCanalType{2},'III')==1
                            % for the last cross-section of tertiary canal enter water surface elevation in the lateral drain
                            Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).HECobserved = Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).terrain - depthLateral;
                        end
                    else
                        % it's not a secondary or tertiary canal, do not enter obsereved water surface elevation
                    end
                clear minstation activeCanalType deltaL 
            % enter total flow for each cross-section
                IDinflow = strcmp(Model.([streamName '_' mat2str(i)]).inflow(:,1),activeXSstation);
                if any(IDinflow) == 1
                    % total flow is defined for this cross-section, enter it
                    Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).inflow = cell2mat(Model.([streamName '_' mat2str(i)]).inflow(IDinflow,3));
                else
                    % total flow is not defined for this cross-section, do not enter it
                end           
                clear activeXSstation IDinflow 
            
            % check that invert elevation is lower than terrain elevation
                LatCanalDepth = Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).terrain - invertElevation;
                if LatCanalDepth > 0
                    % OK
                else
                    msgbox(['Canal invert elevation of ' activeCanal ' is higher than terrain elevation for the station' mat2str(Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).station) '. Terminating function!'], 'Notification');
                    return
                end
            % create a line equation and calculate 4 points: toes and banks
                width_half_btm = Model.([streamName '_' mat2str(i)]).width_btm/2;
                bankProjection = width_half_btm + (LatCanalDepth * Model.([streamName '_' mat2str(i)]).slope_bank);         
                % define position of midpoint (in drainage canal network) from left and right ends of the cross-section
                    xCenter = Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).midpointXS(1,1);
                    yCenter = Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).midpointXS(1,2);
                    xLeft = Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).limitsXS(1,1);
                    yLeft = Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).limitsXS(1,2);
                    xRight = Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).limitsXS(2,1);
                    yRight = Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).limitsXS(2,2);
                    [ELeftBank, NLeftBank] = extend2Dline(xCenter, yCenter, xLeft, yLeft, bankProjection);
                    [ELeftToe, NLeftToe] = extend2Dline(xCenter, yCenter, xLeft, yLeft, width_half_btm);
                    [ERightBank, NRightBank] = extend2Dline(xCenter, yCenter, xRight, yRight, bankProjection);
                    [ERightToe, NRightToe] = extend2Dline(xCenter, yCenter, xRight, yRight, width_half_btm);
                % enter values as cross-section points
                    Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).points(1,1:3)=[ELeftBank NLeftBank elevationTerrainMidpointXS];
                    Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).points(2,1:3)=[ELeftToe NLeftToe invertElevation];
                    Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).points(3,1:3)=[ERightToe NRightToe invertElevation];
                    Model.([streamName '_' mat2str(i)]).(['P_' fieldstation]).points(4,1:3)=[ERightBank NRightBank elevationTerrainMidpointXS];
                 % count how many cross-sections are there in the drawing
                    numberOFcrosssections = numberOFcrosssections +1;
            
    clear partsXSstation fieldstation    
    clear elevationTerrainMidpointXS invertElevation LatCanalDepth width_half_btm bankProjection xCenter yCenter xLeft yLeft xRight yRight
    clear ELeftBank NLeftBank ELeftToe NLeftToe ERightBank NRightBank ERightToe NRightToe
    end
end
clear activeCanal activeReach activeXS XSstations j

end
clear i rawDxfReach rawDxfTerrainX rawDxfTerrainY rawDxfTerrainZ depthLateral


% Calculate the distance from downstream cross-section and control if distances are OK
%reachNames = fields(Model); %INMATLAB
reachNames = fieldnames(Model);
for i=1:size(reachNames,1)
    % find active canal
    activeCanal = Model.(reachNames{i}).name;
    if strcmp(activeCanal,'DC-IV-1')==1
        % active canal is a lateral drain, data is not used for it
    else
        % start counter
        rowCell = 0;
        % find names of all fields in a cell
        namesXS = fieldnames(Model.(reachNames{i})); % read the names of cross-sections in the active Reach
        % for each field, check if it is a cross-section or something else
        for j=1:size(namesXS,1)
            if strcmp(namesXS{j}(1:2),'P_')==1 && size(namesXS{j},2)==6
                % it really is a cross-section, not metadata
                % write data in a cell: (1)cross-section name, (2)station, (3)air distance
                rowCell = rowCell +1;
                % station as a cross-section name
                sortXSstations{rowCell,1} = namesXS{j};
                % numbered station from layer name
                sortXSstations{rowCell,2} = Model.(reachNames{i}).(namesXS{j}).station;
                clear deltaXY
            else
                % not an XS
            end
        end
        % sort the cell by station from layer name (separate the part with data first)
        sortedStations = sortrows(sortXSstations,2);
        % calculate the spacing between cross-sections and control if station data is entered corectly (are station numbers going up in corelation with the distance from the start of the canal)
        for k=1:size(sortedStations,1)
            activeXSHEC = sortedStations{k,1};
            if k==1
                % is it really the first station, control if it is =0
                if sortedStations{k,2} == 0
                    % the first station is 0, insted of the distance write the tolerance
                    Model.(reachNames{i}).(activeXSHEC).HECdistance = tolerance;
                else
                    % the first station is not 0, calculate the actual distance
                    Model.(reachNames{i}).(activeXSHEC).HECdistance = sortedStations{k,2};
                end
            else               
                % calculate the distance to the previous station
                Model.(reachNames{i}).(activeXSHEC).HECdistance = sortedStations{k,2}-sortedStations{k-1,2};
            end
            clear activeXSHEC activeCanalType
        end
        
        clear rowCell namesXS j k sortXSstations sortedStations
    end % if strcmp(activeCanal,'DC-IV-1')==1
    
    clear activeCanal
end % for i=1:size(reachNames,1)
clear i

%% CONTROL OF THE INFLOW IN SECONDARY CANALS
deletedCanals={'ordinalNumberErased'};
numSecondaryCanals = numel(fieldnames(Model));
for i = 1:numSecondaryCanals
    % find active canal
    activeCanal = Model.([streamName '_' mat2str(i)]).name; 
    if strcmp(activeCanal(3:6),'-II-')==1
        % active canal is a secondary canal, find if tertiary canals inflow in it and where
        % extract all stations from this canal
            sortedSecondaryCnl = {'label','station','x coordinate','y coordinate'};
            namesSecondaryCnl = fieldnames(Model.([streamName '_' mat2str(i)]));
            for k =1:size(namesSecondaryCnl,1)
                if strcmp(namesSecondaryCnl{k}(1:2),'P_')==1
                    % field is a cross-section, write it in the table
                    nextRow = size(sortedSecondaryCnl,1)+1;
                    sortedSecondaryCnl{nextRow,1} = 'cross-section'; 
                    sortedSecondaryCnl{nextRow,2} = str2double(namesSecondaryCnl{k}(3:6));
                clear nextRow
                else
                    % field is not a cross-section, do not do anything
                end
            end
            clear k namesSecondaryCnl

        % check if the canal has breaking points
            numSegmentsSecondaryCnl = size(Model.([streamName '_' mat2str(i)]).Reach,1)-1;
            if numSegmentsSecondaryCnl == 1
                % there are no breaking points, only one section
            else
                % reach has at least two sections, calculate breaking point station
                reachTemp = flip(Model.([streamName '_' mat2str(i)]).Reach); % flip for easier calculation of the station
                for nL = 1:size(reachTemp,1)
                    if nL==1 % station is 0
                        reachTemp(nL,3) = 0;
                    else % calculate station
                        % reachTemp(nL,3) = round(reachTemp(nL-1,3)+ sqrt((reachTemp(nL,1)-reachTemp(nL-1,1))^2+(reachTemp(nL,2)-reachTemp(nL-1,2))^2),0); % INMATLAB
                        reachTemp(nL,3) = round(reachTemp(nL-1,3)+ sqrt((reachTemp(nL,1)-reachTemp(nL-1,1))^2+(reachTemp(nL,2)-reachTemp(nL-1,2))^2));
                    end
                end
                % transfer calculated stations in Reach
                Model.([streamName '_' mat2str(i)]).Reach = flip(reachTemp); % flip back
                clear nL reachTemp
                
                % check if a tertiary canal infows on the breaking point
                for nLom = 1:(size(Model.([streamName '_' mat2str(i)]).Reach,1)-2)
                    breakCoordinates = Model.([streamName '_' mat2str(i)]).Reach(nLom+1,1:2);
                    nextRow = size(sortedSecondaryCnl,1)+1;
                    sortedSecondaryCnl{nextRow,2} = Model.([streamName '_' mat2str(i)]).Reach(nLom+1,3);
                    sortedSecondaryCnl{nextRow,3} = Model.([streamName '_' mat2str(i)]).Reach(nLom+1,1);
                    sortedSecondaryCnl{nextRow,4} = Model.([streamName '_' mat2str(i)]).Reach(nLom+1,2);
                    for j = 1:numSecondaryCanals
                        if max(ismember(deletedCanals(:,1),mat2str(j)))==1 || j==i
                            % do not do anything, do not compare the active canal with itself and do not use deleted canals
                        else
                        splitSecName = strsplit(Model.([streamName '_' mat2str(j)]).name,'-');
                        if strcmp(splitSecName(2),'III')==1
                            % canal is a tertiary canal, find out if it's mouth is on the secondary canal breaking point
                            outflowCoordinatesIII = Model.([streamName '_' mat2str(j)]).Reach(end,1:2);
                             outflowDistance = sqrt((breakCoordinates(1,1)-outflowCoordinatesIII(1,1))^2+(breakCoordinates(1,2)-outflowCoordinatesIII(1,2))^2);
                            if outflowDistance < tolerance
                                % secondary canal breaking point is also a junction, write it in the table
                                sortedSecondaryCnl{nextRow,1} = 'junction';
                            else
                                % secondary canal breaking point is not a junction, write it in the table
                                if isempty(cell2mat(sortedSecondaryCnl(nextRow,1)))==1
                                    % there is no written data yet
                                    sortedSecondaryCnl{nextRow,1} = 'breaking point';
                                else
                                    % there is a written value, do not write anything
                                end
                            end
                        else
                            % canal is not a tertiary canal, do not check it's mouth
                        end
                        clear splitSecName outflowCoordinatesIII outflowDistance
                        end
                    end
                    clear j breakCoordinates nextRow imenaCADkanali
                end
                clear nLom
            end
            clear numSegmentsSecondaryCnl
        
        % sort data in ascending order
            outSortedSecondCnl = sortrows(sortedSecondaryCnl(2:end,:),2);
            clear sortedSecondaryCnl
        % enter first and last point in the list   
            outSortedSecondCnl{1,3} = Model.([streamName '_' mat2str(i)]).Reach(end,1); % mouth
            outSortedSecondCnl{1,4} = Model.([streamName '_' mat2str(i)]).Reach(end,2); % mouth
            outSortedSecondCnl{end,3} = Model.([streamName '_' mat2str(i)]).Reach(1,1); % source
            outSortedSecondCnl{end,4} = Model.([streamName '_' mat2str(i)]).Reach(1,2); % source
        % find rows with junctions
            rowJunctionID = ismember(outSortedSecondCnl(:,1),'junction');
            rowsJunctions = find(rowJunctionID);
            numberSubreaches = size(rowsJunctions,1)+1;
        % Find subreach edges locations
            for j = 1:numberSubreaches
                % return rows in which subReach starts
                    if numberSubreaches ==1
                        firstRow = size(outSortedSecondCnl,1);
                        finalRow = 1;
                    elseif j==1
                        firstRow = rowsJunctions(j,1);
                        finalRow = 1;
                    elseif j<numberSubreaches
                        firstRow = rowsJunctions(j,1);
                        finalRow = rowsJunctions(j-1,1);
                    elseif j==numberSubreaches
                        firstRow = size(rowJunctionID,1);
                        finalRow = rowsJunctions(j-1,1);
                    end
                 % find how many sections (breaking points on route) is there in a subReach
                    outSubreachSec=outSortedSecondCnl(min(firstRow,finalRow):max(firstRow,finalRow),:);
                    clear firstRow finalRow
                        % find the number of breaking points
                        rowBreakID = ismember(outSubreachSec(:,1),'breaking point');
                        rowsBreak = find(rowBreakID);
                        numSegmentsSecondaryCnl = size(rowsBreak,1)+1;
                    % Find location of the edges for each section
                        for jj = 1:numSegmentsSecondaryCnl
                        % return rows in which a section starts
                            if numSegmentsSecondaryCnl ==1
                                startPoint = cell2mat(outSubreachSec(size(outSubreachSec,1),3:4));
                                endPoint = cell2mat(outSubreachSec(1,3:4));
                                startStation = outSubreachSec{1,2};
                            elseif jj==1
                                startPoint = cell2mat(outSubreachSec(rowsBreak(jj,1),3:4));
                                endPoint = cell2mat(outSubreachSec(1,3:4));
                                startStation = outSubreachSec{1,2};
                            elseif jj<numSegmentsSecondaryCnl
                                startPoint = cell2mat(outSubreachSec(rowsBreak(jj,1),3:4));
                                endPoint = cell2mat(outSubreachSec(rowsBreak(jj-1,1),3:4));
                                startStation = outSubreachSec{rowsBreak(jj-1,1),2};
                            elseif jj==numSegmentsSecondaryCnl
                                startPoint = cell2mat(outSubreachSec(size(outSubreachSec,1),3:4));
                                endPoint = cell2mat(outSubreachSec(rowsBreak(jj-1,1),3:4));
                                startStation = outSubreachSec{rowsBreak(jj-1,1),2};
                            end
                            
                        % for each section check if tertiary canal mouth points are located between first and last point of the Section
                        % check if tertiary canal mouth points are located between first and last point of the canal
                            % find canal names in the model (after deleting each secondary canal)
                            for k = 1:numSecondaryCanals
                                if max(ismember(deletedCanals(:,1),mat2str(k)))==1 || k==i
                                    % do not do anything, do not compare the active canal with itself and do not use deleted canals
                                else
                                    splitSecName = strsplit(Model.([streamName '_' mat2str(k)]).name,'-');
                                if strcmp(splitSecName(2),'III')==1
                                    % canal is a tertiary canal, find out if it's mouth is on a secondary canal section
                                    outflowCoordinatesIII = Model.([streamName '_' mat2str(k)]).Reach(end,1:2);
                                    outflowProjection = drainageCanalOutlet(outflowCoordinatesIII, startPoint, endPoint, tolerance);
                                    if iscell(outflowProjection)==1
                                        % tertiary canal inflows in a secondary canal, add a junction if it does not already exist
                                            % return junction stations
                                                junctionsRowID = ismember(outSortedSecondCnl(:,1),'junction');
                                                junctionsRows = find(junctionsRowID);
                                                junctionsStations = cell2mat(outSortedSecondCnl(junctionsRows,2));
                                                junctionsDelta = abs(junctionsStations - round(startStation + outflowProjection{3}));
                                                if all(junctionsDelta>tolerance*2)
                                                    % tertiary canal inflows in a secondary canal on it's straight reach, enter it 
                                                        rowJunction = size(outSortedSecondCnl,1)+1;
                                                        outSortedSecondCnl{rowJunction,1} = 'junction';
                                                        outSortedSecondCnl{rowJunction,2} = round(startStation + outflowProjection{3});
                                                        outSortedSecondCnl{rowJunction,3} = outflowProjection{1}(1); % X projection coordinate
                                                        outSortedSecondCnl{rowJunction,4} = outflowProjection{1}(2); % Y projection coordinate
                                                        outSortedSecondCnl{rowJunction,5} = Model.([streamName '_' mat2str(k)]).name;
                                                     % secondary canal infolws in an existing junction, do not write it
                                                end
                                                clear junctionsRowID junctionsRows junctionsStations junctionsDelta
                                    else
                                        % tertiary canal does not inflow in a secondary canal
                                    end
                                    clear outflowCoordinatesIII outflowProjection rowJunction
                                else
                                    % canal is not a tertiary canal, do not check it's mouth
                                end
                                clear splitSecName
                                end
                            end
                            clear k startPoint endPoint startStation
                        end
                        clear jj rowBreakID rowsBreak numSegmentsSecondaryCnl outSubreachSec
            end
            clear j rowJunctionID rowsJunctions numberSubreaches
            
        % insert the secondary canal break here
            % sort secondary canal points by ascending stations
                outSortedSecondCnl = sortrows(outSortedSecondCnl,2);               
            % find double entries in the matrix outSortedSecondCnl if double entries exist, junction must be above the cross-section (because it's station is calculated by adding the distance to the mouth station - defined in CAD)
                [nOR, binOR] = histc(cell2mat(outSortedSecondCnl(:,2)), unique(cell2mat(outSortedSecondCnl(:,2))));
                multipleOR = find(nOR > 1);
                if isempty(multipleOR)==1
                    % all station numbers are unique, do not do anything
                else
                    % double station numbers exist, single out the segment in which they are
                    for j=1:size(multipleOR,1)
                        indexOR = find(ismember(binOR, multipleOR(j,1)));
                        if size(indexOR,1) > 2
                            % three or more junctions/cross-sections have the same station
                            % notification
                            msgbox(['On canal ' activeCanal ' there are two cross-sections with the same station on tertiary canal mouth or stations do not match real distances of the reach. Adjust stations! Leave code.'], 'Notification');
                            return
                        else
                            segmentOR = outSortedSecondCnl(indexOR,:);
                            % check if the junction is above the cross-section
                            if strcmp(segmentOR{1,1},'junction')==1 && strcmp(segmentOR{2,1},'cross-section')==1
                                % everything is OK, junction is above the cross-section
                            elseif strcmp(segmentOR{1,1},'cross-section')==1 && strcmp(segmentOR{2,1},'junction')==1
                                % swap rows
                                segmentOR = flip(segmentOR,1);
                                outSortedSecondCnl(indexOR,:) = segmentOR;
                            end
                        end
                        clear indexOR segmentOR 
                    end
                    clear j
                end
                clear nOR binOR multipleOR 
                    
            % check if there are two cross-sections on each reach
            % find rows with junctions
                rowJunctionFinalID = ismember(outSortedSecondCnl(:,1),'junction');
            % check if there are at least two cross-sections between all junctions
                transitions = diff([0; rowJunctionFinalID == 0; 0]); %find where the array goes from non-zero to zero and vice versa
                runstarts = find(transitions == 1);
                runends = find(transitions == -1); %one past the end
                runlengths = runends - runstarts;
                shortestRun = min(runlengths);
                if shortestRun <2
                    % there aren't at least two cross-sections between tertiary canal mouths
                    % notification
                    msgbox(['On canal ' activeCanal ' there are less than two cross-sections between tertiary canal outflows. Terminating function!'], 'Notification');
                    return
                else
                    % there are at least two cross-sections between canal mouths
                end
                clear transitions runstarts runends runlengths shortestRun
                
             % Return the number of existing canals in the model and the number of new reaches which will become canals
                numCanals = size(fieldnames(Model),1); % current number of canals
                rowJunctionFinal = find(rowJunctionFinalID);
                numNewReaches = size(rowJunctionFinal,1)+1; % number of new reaches from secondary canals
                numXSID = find(ismember(outSortedSecondCnl(:,1),'cross-section'));
            clear measurements shortestRun indexOfShortestRun zerospan rowJunctionFinalID
                
            % Break the secondary canal to get more shorter sections from junction to junction
                for nS=1:numNewReaches
                    newSegment = [streamName '_' mat2str(numCanals+nS)];
                    % enter values in a new segment
                        Model.(newSegment).name = [activeCanal '(' mat2str(nS) ')'];
                        Model.(newSegment).manning = Model.([streamName '_' mat2str(i)]).manning;
                    % find data of the new streamline
                        if numNewReaches==1
                            % boundary points: take over first and last point for the reach
                                boundaryReachPoints = [1, size(outSortedSecondCnl,1)];      
                        elseif nS==1
                            % boundary points: take over first point and juntion after the cross-section for the last point of the reach
                                boundaryReachPoints = [1 ,rowJunctionFinal(nS,1)]; 
                        elseif nS<numNewReaches
                            % boundary points: take over junctions before and after the cross-section for the first and last point of the reach
                                boundaryReachPoints = [rowJunctionFinal(nS-1,1), rowJunctionFinal(nS,1)];                             
                        elseif nS==numNewReaches
                            % boundary points: take over the junction before the cross-section for the first point of the reach and the last point
                                boundaryReachPoints = [rowJunctionFinal(nS-1,1), size(outSortedSecondCnl,1)];                             
                        else
                        end
                    % enter data for the Reach
                        Model.(newSegment).Reach = flip(cell2mat(outSortedSecondCnl(boundaryReachPoints(1):boundaryReachPoints(2),3:4)),1);  
                    % find data about cross-sections for the new reach
                        for nP = 1:size(numXSID,1)
                            workingXS = numXSID(nP,1);
                            workingStation = outSortedSecondCnl{workingXS,2};
                            if workingXS >= boundaryReachPoints(1) && workingXS <= boundaryReachPoints(2)
                                    % take over the name of the cross-section
                                    if workingStation < 10
                                        nameXS = ['P_000' mat2str(workingStation)];
                                    elseif workingStation < 100
                                        nameXS = ['P_00' mat2str(workingStation)];
                                    elseif workingStation < 1000
                                        nameXS = ['P_0' mat2str(workingStation)];
                                    else
                                        nameXS = ['P_' mat2str(workingStation)];
                                    end
                                 % check if there is a field with that name in the original inscription
                                    if isfield(Model.([streamName '_' mat2str(i)]),nameXS) == 1
                                        % there is, rewrite it in a new inscription
                                        Model.(newSegment).(nameXS) = Model.([streamName '_' mat2str(i)]).(nameXS);
                                    else
                                        % there is no cross-section, report an error
                                        msgbox(['On canal ' activeCanal ' there are no cross-sections' nameXS '! Leave code.'], 'Notification');
                                        return
                                    end
                                    clear nameXS
                            else
                            end
                            clear workingStation workingXS
                        end
                        clear newSegment nP polja boundaryReachPoints
                end
                clear numCanals rowJunctionFinal numNewReaches numXSID nS
                clear outSortedSecondCnl 
                % write canals that need to be erased in the variable
                deletedCanals{size(deletedCanals,1)+1,1} = mat2str(i);
    else
        % active canal is not a secondary canal, do not do anything
    end
    clear activeCanal
 
end
clear i numSecondaryCanals

% delete canals - delete the field with the original secondary canal because there is a new one now 
for nB = 2:size(deletedCanals,1)
Model = rmfield(Model,([streamName '_' deletedCanals{nB,1}]));
end
clear nB deletedCanals

% delete secondary canals that have addition (1) in their names, and aren't broken in sections
% make a temporary variable
    namesCurrent = {'field name', 'canal type', 'canal name', 'subReach name'};
    reachNames = fieldnames(Model); %izvlaci imena Reachova u varijablu
    for nK=1:size(reachNames,1)
        % find the active canal
        %activeCanalSplit = regexp(Model.(reachNames{nK}).name,'-','split'); %INMATLAB
        activeCanalSplit = strsplit(Model.(reachNames{nK}).name,'-');
        if strcmp(activeCanalSplit{2},'II')==1
            % canal is a secondary canal, write names in the variable
            rowCurrent = size(namesCurrent,1)+1;
            namesCurrent{rowCurrent,1} = reachNames{nK};
            namesCurrent{rowCurrent,2} = activeCanalSplit{2};
            % find the real name of Reach and SubReach
            %activeSubreachBrackets = regexp(activeCanalSplit{3},{'(' ')'}); %INMATLAB
            activeSubreachBrackets = strsplit(activeCanalSplit{3},{'(' ')'});
            %activeReach = activeCanalSplit{3}(1:activeSubreachBrackets{1}-1);
            activeReach = activeSubreachBrackets{1};
            %activeSubreach = activeCanalSplit{3}(activeSubreachBrackets{1}+1:activeSubreachBrackets{2}-1);
            activeSubreach = activeSubreachBrackets{2};
            namesCurrent{rowCurrent,3} = [activeCanalSplit{1} '-' activeCanalSplit{2} '-' activeReach];
            namesCurrent{rowCurrent,4} = activeSubreach;
        else
            % canal is not a secondary canal, ignore
        end
        clear activeCanalSplit activeSubreachBrackets activeReach activeSubreach rowCurrent
    end
clear reachNames nK
         
% from the temporary variable, for each individual secondary canal determine if it is broken in sections (if it has more subreaches)
    secCanalsNames = namesCurrent(2:end,3);
    for nK=2:size(namesCurrent,1)
        activeCanal = namesCurrent{nK,3};
        % find out how many times does the name secondary canal appear
            numberSubreaches = sum(ismember(secCanalsNames,activeCanal));
            if numberSubreaches>1
                % there are more than one canal, do not do anything
            else
                % there is only one secondary canal, return it's original name
                Model.(namesCurrent{nK,1}).name = activeCanal;
            end
        clear activeCanal numberSubreaches
        
        % delete observed water level in the last cross-section
            activeField = namesCurrent{nK,1};
            namesSecondaryCnl = fieldnames(Model.(activeField));
            namesXS = {'cross-section', 'Station'};
            for k =1:size(namesSecondaryCnl,1)
                if strcmp(namesSecondaryCnl{k}(1:2),'P_')==1
                    % field is a cross-section, write it in the table
                    rowXS = size(namesXS,1)+1;
                    namesXS{rowXS,1} = namesSecondaryCnl{k};
                    namesXS{rowXS,2} = str2double(namesSecondaryCnl{k}(3:end));
                    clear rowXS
                else
                    % field is not a cross-section, do not do anything
                end
            end
            % Find the last cross-section
            maxXS = max(cell2mat(namesXS(2:end,2)));
            IDmaxXS = ismember(cell2mat(namesXS(2:end,2)),maxXS);
            stationsProfile = namesXS(2:end,1);
            maxXSField = cell2mat(stationsProfile(IDmaxXS));
                if isfield(Model.(activeField).(maxXSField),'HECobserved')==1
                    % delete the field with water surface elevation on the upstream cross-section
                    Model.(activeField).(maxXSField) = rmfield(Model.(activeField).(maxXSField),'HECobserved');
                else
                    % for some reason water surface elevation is not entered, which is impossible
                end
            clear activeField namesSecondaryCnl namesXS k maxXS IDmaxXS stationsProfile maxXSField    
    end
clear secCanalsNames nK reachNames namesCurrent
    
    
%% Preparation for HEC

% sort reach names for .f01 structure
modelFields = fieldnames(Model);
    for nP=1:size(modelFields,1)
        modelFieldsSort{nP,1} = Model.(modelFields{nP}).name;
        modelFieldsSort{nP,2} = modelFields{nP};
    end
modelFieldsSorted = sortrows(modelFieldsSort,1);  
reachNames = modelFieldsSorted(:,2); %extract Reach names and enter them in the variable
clear modelFields nP modelFieldsSort modelFieldsSorted 

numberOFreaches = 0; % activate counter
Endpoints = {'Reach' 'E' 'N' 'POINT TYPE' 'Ordinal number'}; % variable for writing Reach edges is activated

% Processing REACH for HEC
    for i=1:size(reachNames,1)
    % find the active canal
    activeCanal = Model.(reachNames{i}).name;
        if strcmp(activeCanal,'DC-IV-1')==1
            % active canal is a lateral drain, data isn't used for it
        else
        % writing the variable for entering reach boundary points: (1)Reach (2)E (3)N (4)POINT TYPE (5)Ordinal number
            % find cell size
                rowEP = size(Endpoints,1)+1;
            % Starting point
                startPoints = Model.(reachNames{i}).Reach(1,1:2);
                Endpoints {rowEP,1} = activeCanal;
                Endpoints {rowEP,2} = startPoints(1,1);
                Endpoints {rowEP,3} = startPoints(1,2);
                Endpoints {rowEP,4} = 'START';
                Endpoints {rowEP,5} = rowEP-1;
            % End point
                endPoints = Model.(reachNames{i}).Reach(end,1:2);
                Endpoints {rowEP+1,1} = activeCanal;
                Endpoints {rowEP+1,2} = endPoints(1,1);
                Endpoints {rowEP+1,3} = endPoints(1,2);
                Endpoints {rowEP+1,4} = 'END';
                Endpoints {rowEP+1,5} = rowEP;
            % count how many reaches are there
                numberOFreaches = numberOFreaches +1;
        clear rowEP startPoints endPoints
        end
        clear activeCanal
    end
    clear i 
    
    % filter double point ordinal numbers from the 5th column (start from the 3rd row because header is in the 1st row, and in the second row is the first point which does not need to be checked)   
        for i=3:size(Endpoints,1)
            % return pairs of points E and N
                activePointsE = cell2mat(Endpoints(i,2));
                activePointsN = cell2mat(Endpoints(i,3));
                previousPointsE = cell2mat(Endpoints(2:i-1,2));
                previousPointsN = cell2mat(Endpoints(2:i-1,3));
            % check if the same point already exists in the inscription (with tolerance) because then it has to have the same ordinal number
                %duplicateEpoint = ismembertol(previousPointsE,activePointsE,tolerance,'DataScale',1); %INMATLAB
                duplicateEpoint = ismember(previousPointsE,activePointsE);
                %duplicateNpoint = ismembertol(previousPointsN,activePointsN,tolerance,'DataScale',1); % INMATLAB
                duplicateNpoint = ismember(previousPointsN,activePointsN);
            % return rows in which there is the same point for E and for N
                duplicateRows = mean([duplicateEpoint duplicateNpoint],2);
                IDduplicateRows = ismember(duplicateRows,1);
            % return ordinal numbers from all points
                allPointsRbr = cell2mat(Endpoints(2:i-1,5));
                if  isempty(allPointsRbr(IDduplicateRows)) == 1
                    % There is not a same point in the inscription, assign the next ordinal number to it
                    Endpoints {i,5} = max(allPointsRbr)+1;
                else
                    % same point already exists in the inscription, use it's ordinal number
                    Endpoints {i,5} = mean(allPointsRbr(IDduplicateRows));
                end

        clear activePointsE activePointsN previousPointsE previousPointsN duplicateEpoint duplicateNpoint IDduplicateRows duplicateRows allPointsRbr
        end
        clear i tolerance
        
    % check if there is a point in which two canals connect (must not exist because it is not a JUNCTION)
        junctionsOrdinal = cell2mat(Endpoints(2:end,5));
        junctionsAll = unique(junctionsOrdinal);
            % check how many canals connect in every junction
            for i=1:size(junctionsAll)
                % find how many junctions are there in the inscription
                    rowJunctionOrdinal = ismember(junctionsOrdinal,junctionsAll(i));
                    rowsJunctions = find(rowJunctionOrdinal);
                    if size(rowsJunctions,1) > 2
                        % more canals connect in the junction, everything is OK
                    elseif size(rowsJunctions,1) == 1
                        % these are canal edges
                    elseif size(rowsJunctions,1) == 2
                        % THIS IS A JUNCTION WITH ONLY TWO CANALS
                        % CHECK IF IT'S A PRIMARY OR A SECONDARY CANAL
                        junctionCanals = Endpoints(rowsJunctions+1,1);
                        if strcmp(junctionCanals{1}(1:5),'DC-I-') == 1 && strcmp(junctionCanals{2}(1:6),'DC-II-') == 1
                            % it is an extension of the primary canal on the secondary canal, join them
                            IDcanal_1 = find(ismember(Endpoints(:,1),junctionCanals{1}));
                            IDcanal_2 = find(ismember(Endpoints(:,1),junctionCanals{2}));
                            deleteCanal = junctionCanals{2};
                        elseif strcmp(junctionCanals{1}(1:6),'DC-II-') == 1 && strcmp(junctionCanals{2}(1:5),'DC-I-') == 1
                            % it is an extension of the secondary canal on the primary canal, join them
                            IDcanal_1 = find(ismember(Endpoints(:,1),junctionCanals{2}));
                            IDcanal_2 = find(ismember(Endpoints(:,1),junctionCanals{1}));
                            deleteCanal = junctionCanals{1};
                        else
                            % something is weird with canals, show an error
                            msgbox(['canals ' junctionCanals{1}  ' and ' junctionCanals{2} ' need to be joined as one. Terminating function!'], 'Obavijest');
                            return % leave code
                        end
                        IDcanals = sort(vertcat(IDcanal_1, IDcanal_2));
                            for j=1:size(IDcanals)
                                if strcmp(Endpoints{IDcanals(j),1},'DC-I-1') == 1 && strcmp(Endpoints{IDcanals(j),4},'END') == 1
                                    % do not do anything, leave the point as the end of the primary canal
                                elseif strcmp(Endpoints{IDcanals(j),1},'DC-I-1') == 1 && strcmp(Endpoints{IDcanals(j),4},'START') == 1
                                    % insert NAN in the cell in that row
                                    Endpoints{IDcanals(j),1} = NaN; Endpoints{IDcanals(j),2} = NaN; Endpoints{IDcanals(j),3} = NaN; Endpoints{IDcanals(j),4} = NaN; Endpoints{IDcanals(j),5} = NaN;
                                elseif strcmp(Endpoints{IDcanals(j),1},deleteCanal) == 1 && strcmp(Endpoints{IDcanals(j),4},'END') == 1
                                    % insert NAN in the cell in that row
                                    Endpoints{IDcanals(j),1} = NaN; Endpoints{IDcanals(j),2} = NaN; Endpoints{IDcanals(j),3} = NaN; Endpoints{IDcanals(j),4} = NaN; Endpoints{IDcanals(j),5} = NaN;
                                elseif strcmp(Endpoints{IDcanals(j),1},deleteCanal) == 1 && strcmp(Endpoints{IDcanals(j),4},'START') == 1
                                    % rename the beginning of the primary canal to DC-I-I
                                    Endpoints{IDcanals(j),1} = 'DC-I-1';
                                end
                            end
                            clear junctionCanals IDcanal_1 IDcanal_2 IDcanals j
                    end               
            clear rowJunctionOrdinal rowsJunctions
            end
            clear junctionsOrdinal junctionsAll i

    % delete empty rows from the cell
    Endpoints = Endpoints(all(cellfun(@(x)any(~isnan(x)),Endpoints),2),:);
    
    % return distances in Reach
    for i=2:size(Endpoints,1)
        activeCanalEP = Endpoints{i,1};
        for j=1:size(reachNames,1)
            activeCanalM = Model.(reachNames{j}).name;
            if strcmp(activeCanalEP,activeCanalM)==1
                % it is the same canal, check which point is it
                if strcmp(Endpoints{i,4},'START')==1
                    % beginning of the canal, enter it
                    Model.(reachNames{j}).Reach(1,1:2)= cell2mat(Endpoints(i,2:3));
                elseif strcmp(Endpoints{i,4},'END')==1
                    % canal mouth, enter it
                    Model.(reachNames{j}).Reach(end,1:2)= cell2mat(Endpoints(i,2:3));
                else
                end
            else
                % canal does not match, continue searching
            end
            clear activeCanalM
        end
        clear j activeCanalEP
    end
    clear i
    
    % if two canals really connect, delete DC-II
    if exist('deletecanal','var') == 1
        % correct the number of reaches
            numberOFreaches = numberOFreaches -1;
        % identify canals which connect to each other
            for j=1:size(reachNames,1)
                % find a canal that will be deleted
                if strcmp(Model.(reachNames{j}).name, deleteCanal) == 1 
                    % delete this canal
                    canalDelete = reachNames{j};
                elseif strcmp(Model.(reachNames{j}).name, 'DC-I-1') == 1 
                    % fill this canal 
                    canalRefresh = reachNames{j};
                end
            end
        clear j
        
        % find the biggest station in canal DC-I
            fields_DC_1 = fieldnames(Model.(canalRefresh));
            stationMax = 0;
            for k=1:size(fields_DC_1,1)
                if strcmp(fields_DC_1{k}(1:2),'P_')==1
                    % cross-section, find out it's station
                    stationActive = str2double(fields_DC_1{k}(3:end));
                    if stationActive > stationMax
                        stationMax = stationActive;
                    else
                    end 
                else
                end
                clear stationActive
            end
            clear k fields_DC_1
         % to cross-sections in canal DC-II add max station and transfer them in canal DC-I
            fields_DC_2 = fieldnames(Model.(canalDelete));
            for l=1:size(fields_DC_2,1)
                if strcmp(fields_DC_2{l}(1:2),'P_')==1
                    % cross-section, find out it's station
                        stationActive = str2double(fields_DC_2{l}(3:end));
                        stationNew = stationActive + stationMax + 10; % 10 is the distance from junction
                        if stationNew < 100
                            stationCopy = ['P_00' mat2str(stationNew)];
                        elseif stationNew < 1000
                            stationCopy = ['P_0' mat2str(stationNew)];
                        else
                            stationCopy = ['P_' mat2str(stationNew)];
                        end
                    % copy cross-section in DC-I with a new name
                        Model.(canalRefresh).(stationCopy) = Model.(canalDelete).(fields_DC_2{l});
                    % rename the station inside the reach
                        Model.(canalRefresh).(stationCopy).station = stationNew;
                    % add up all points that descripe the Reach in one Array
                        reachPoints_DC2 = Model.(canalDelete).Reach;
                        reachPoints_DC1 = Model.(canalRefresh).Reach(2:end,1:2);
                        Model.(canalRefresh).Reach = vertcat(reachPoints_DC2,reachPoints_DC1);
                        clear reachPoints_DC2 reachPoints_DC1
                else
                    % not a cross-section, ignore
                end
                clear stationActive stationNew stationCopy
            end
            clear l fields_DC_2 stationMax
        % delete the secondary canal
        Model = rmfield(Model,canalDelete);
    else
        % there isn't a connection between two canals, continue farther
    end
    clear canalDelete canalRefresh deleteCanal reachNames
    
    
    
%% PREPARE .sdf FILE

% .sdf file will open here
fid=fopen(sdfPathOut,'wt');
fprintf(fid, '%s\n', ['# created by >DrainCAN< on ' date ]); % writes a comment
fprintf(fid, '\n'); %empty row for better legibility
     
% HEADER
fprintf(fid, '%s\n', 'BEGIN HEADER:');
fprintf(fid, '%s\n', 'DTM TYPE:');
fprintf(fid, '%s\n', 'DTM:');
fprintf(fid, '%s\n', 'STREAM LAYER:');
fprintf(fid, 'NUMBER OF REACHES: %d\n', numberOFreaches);
fprintf(fid, '%s\n', 'CROSS-SECTION LAYER:');
fprintf(fid, 'NUMBER OF CROSS-SECTIONS: %.0f\n', numberOFcrosssections);
fprintf(fid, '%s\n', 'MAP PROJECTION:');
fprintf(fid, '%s\n', 'PROJECTION ZONE:');
fprintf(fid, '%s\n', 'DATE:');
fprintf(fid, '%s\n', 'VERTICAL DATUM:');
fprintf(fid, '%s\n', 'BEGIN SPATIAL EXTENT:');
fprintf(fid, 'XMIN: %0.0f\n', Extent(1)); %Emin
fprintf(fid, 'YMIN: %0.0f\n', Extent(2)); %Nmin
fprintf(fid, 'XMAX: %0.0f\n', Extent(3)); %Emax
fprintf(fid, 'YMAX: %0.0f\n', Extent(4)); %Nmax
fprintf(fid, '%s\n', 'END SPATIAL EXTENT:');
fprintf(fid, '%s\n', 'UNITS: METERS');
fprintf(fid, '%s\n', 'END HEADER:');
fprintf(fid, '\n'); % empty row for better legibility

clear FileNameM Extent

% STREAM NETWORK
fprintf(fid, '%s\n', 'BEGIN STREAM NETWORK:');
fprintf(fid, '\n'); %empty row for better legibility

Endpoints = Endpoints(2:end,1:5); % remove header row
ordinalNrEndpoint = unique(cell2mat(Endpoints(:,5))); % enterend Endpoint points
nEndpoints = size(ordinalNrEndpoint,1); % number of entered Endpoint points in total
for i=1:nEndpoints 
    [~, indexEP] = ismember(ordinalNrEndpoint(i),cell2mat(Endpoints(:,5)));
    %E = sprintf('%0.2f', Endpoints{indexEP,2}); % used for rounding up to 2 decimal places (unfortunatly by doing that number becomes a text)
    E = Endpoints{indexEP,2};
    N = Endpoints{indexEP,3};
fprintf(fid, 'ENDPOINT: %0.2f, %0.2f, %s, %d\n',  E,  N, '', i);

end
fprintf(fid, '\n'); %empty row for better legibility

clear i E N indexEP ordinalNrEndpoint

reachNames = fieldnames(Model); %extract names of Reaches in the variable
for j=1:size(reachNames,1)
% find active canal
activeReach = Model.(reachNames{j}).name; 
    if strcmp(activeReach,'DC-IV-1')==1
        % active reach is a lateral drain, data isn't used for it
    else
        reach = activeReach;
    fprintf(fid, '%s\n', 'REACH:');
    fprintf(fid, '%s\n', ['STREAM ID: ' streamName]);
    fprintf(fid, '%s\n', ['REACH ID: ' reach]);
        rnReach=find(strcmp(activeReach,Endpoints(:,1))); % find row with the active reach (activeReach)
        rnStart=find(strcmp('START',Endpoints(:,4))); % find the row with all START points
        rnEnd=find(strcmp('END',Endpoints(:,4))); % find the row with all END points
        ptStart = intersect(rnReach, rnStart); % find a common row to these two points
        ptEnd = intersect(rnReach, rnEnd); % find a common row to these two points
    fprintf(fid, 'FROM POINT: %d\n', Endpoints{ptStart,5});
    fprintf(fid, 'TO POINT: %d\n',   Endpoints{ptEnd,5});
    fprintf(fid, '%s\n', 'CENTERLINE:');
                [brGeo, ~] = size(Model.(reachNames{j}).Reach); % number of points in geoposition of the Reach stream line
             for k=1:brGeo
                 E = Model.(reachNames{j}).Reach(k,1);
                 N = Model.(reachNames{j}).Reach(k,2);
    fprintf(fid, '%0.2f, %0.2f\n',  E,  N);
             end

    fprintf(fid, '%s\n', 'END:');
    fprintf(fid, '\n'); %empty row for better legibility
    end 
end % for j=1:size(reachNames,1)

fprintf(fid, '%s\n', 'END STREAM NETWORK:');
fprintf(fid, '\n'); %empty row for better legibility
    
clear j k Endpoints nEndpoints activeReach remain reach rnReach rnStart rnEnd ptStart ptEnd brGeo E N Z rkm

% CROSS-SECTIONS

fprintf(fid, '%s\n', 'BEGIN CROSS-SECTIONS:');
fprintf(fid, '\n'); %empty row for better legibility

for i=1:size(reachNames,1)
% find active canal
activeReach = Model.(reachNames{i}).name; 
    if strcmp(activeReach,'DC-IV-1')==1
        % active reach is a lateral drain, data isn't used for it
    else
        reach = activeReach;
        namesXS = fieldnames(Model.(reachNames{i})); % extract cross-section names in active Reach
        [p, ~] = size(namesXS); % returns the number of cross-sections (+1)
        for j=1:p % from 1 to p cross-sections in the reach
            activeXSname = cell2mat(namesXS(j,1)); % active cross-section name
            if strcmp(activeXSname(1:2), 'P_')==1 && size(namesXS{j},2)==6 %active cross-section is really a cross-section, not metadata
                station = mat2str(Model.(reachNames{i}).(activeXSname).station); % extracts station from the cross-section name
                fprintf(fid, '%s\n', 'CROSS-SECTION:');
                fprintf(fid, '%s\n', ['STREAM ID: ' streamName]);
                fprintf(fid, '%s\n', ['REACH ID: ' reach]);
                fprintf(fid, '%s\n', ['STATION: ' station]);
                fprintf(fid, '%s\n', 'NODE NAME:'); % cross-section name will be given by the station, for control
                clear station

                % bank points - position the banks on cross-section edges
                LO = 0;
                DO = 1;
                fprintf(fid, 'BANK POSITIONS: %0.0f, %0.0f\n',  LO,  DO);
                clear LO DO
                
                % cross-section spacing
                CHD = Model.(reachNames{i}).(activeXSname).HECdistance(1,1);
                fprintf(fid, 'REACH LENGTHS: %0.0f, %0.0f, %0.0f\n', CHD, CHD, CHD);
                clear CHD
                
                % geoposition
                fprintf(fid, '%s\n', 'CUT LINE:');
                    [g, ~] = size(Model.(reachNames{i}).(activeXSname).points); % returns the number of points in geoposition
                    for k=1:g
                        CLE = Model.(reachNames{i}).(activeXSname).points(k,1);
                        CLN = Model.(reachNames{i}).(activeXSname).points(k,2);
                        fprintf(fid, '%0.2f, %0.2f\n',  CLE,  CLN);
                    end
                clear k g CLE CLN
                
                % profile points
                fprintf(fid, '%s\n', 'SURFACE LINE:');
                    [t, ~] = size(Model.(reachNames{i}).(activeXSname).points);
                    for s=1:t
                        SLE = Model.(reachNames{i}).(activeXSname).points(s,1);
                        SLN = Model.(reachNames{i}).(activeXSname).points(s,2);
                        SLZ = Model.(reachNames{i}).(activeXSname).points(s,3);
                        fprintf(fid, '%0.2f, %0.2f, %0.2f\n',  SLE,  SLN, SLZ);
                    end
                clear s t SLE SLN SLZ
                
                % manning coefficient    
                fprintf(fid, '%s\n', 'N VALUES:');
                    manning = Model.(reachNames{i}).manning;
                fprintf(fid, '%0.0f, %0.3f\n',  0, manning);
                clear manning
                
                % finish segment
                fprintf(fid, '%s\n', 'END:');
                fprintf(fid, '\n'); %empty row for better legibility
                
            else
                % not a cross-section, it's a Reach inscription, do not write anything
            end % if strcmp(activeXSname(1:2), 'P_')==1 && size(namesXS{j},2)==6
            
            clear activeXSname
        end % for j=1:p % od 1 do p profila u reachu

    clear reach namesXS j p 
    end % if strcmp(activeReach,'DC-IV-1')==1
    
clear activeReach
end % for i=1:size(reachNames,1)
clear i

fprintf(fid, '%s\n', 'END CROSS-SECTIONS:');
fprintf(fid, '\n'); %empty row for better legibility

% END OF .sdf FILE
fprintf(fid, '%s\n', '#End Of File'); % end of file
fclose(fid);
clear fid numberOFreaches numberOFcrosssections

%% PREPARE .f01 FILE

% .f01 file will open here
fid=fopen(flowPathOut,'wt');
fprintf(fid, '%s\n', 'Flow Title=Inflow'); % Write names of boundary conditions
fprintf(fid, 'Number of Profiles= %0.0f\n', 1); % write the number of hydrological events
fprintf(fid, '%s\n', 'Profile Names=Q[m3/s]'); % write the names of hydrological events
fprintf(fid, '\n'); %empty row for better legibility

% next part of the code refers to the list of rivers and reaches, also the station of every cross-section for entering flow changes
    for i=1:size(reachNames,1)
    % find active canal
    activeReach = Model.(reachNames{i}).name;
        if strcmp(activeReach,'DC-IV-1')==1
            % active reach is a lateral drain, data isn't used for it
        else
            reach = activeReach;
            namesXS = fieldnames(Model.(reachNames{i})); % extract cross-section names in active Reach
            namesXS = flip(sortrows(namesXS)); % flip the matrix so that the largest stations are at the top for a more logical input of data in HEC
            [p, ~] = size(namesXS); % returns the number of cross-sections (+1)
            for j=1:p % from 1 to p cross-sections in a reach
                activeXSname = cell2mat(namesXS(j,1)); % name of the active cross-section
                if strcmp(activeXSname(1:2), 'P_')==1 && size(namesXS{j},2)==6 % active cross-section is really a cross-section, not metadata
                    station = mat2str(Model.(reachNames{i}).(activeXSname).station); % station is extracted from the cross-section name
                    % enter the part of the string that refers to the change in flow
                    fprintf(fid, '%s\n', ['River Rch & RM=' streamName ',' reach ',' station]);
                    if isfield(Model.(reachNames{i}).(activeXSname),'inflow')==1
                        % enter total flow
                        fprintf(fid, '%s\n', mat2str(round(Model.(reachNames{i}).(activeXSname).inflow(1,1)*100)/100));
                    else
                        % there is no entered value for flow
                    end
                    fprintf(fid, '\n'); %new row for better legibility
                else
                    % not a cross-section for the inscription of Reach, do not write anything
                end % if strcmp(activeXSname(1:2), 'P_')==1 && size(namesXS{j},2)==6

                clear station activeXSname
            end % for j=1:p % from 1 to p cross-sections in reach

        % when active canal is DC-I-I, take over it's slope for downstream boundary condition
        if strcmp(activeReach,'DC-I-1')==1
            downstreamBC = Model.(reachNames{i}).slope_canal;
        else
        end
        
        clear reach namesXS j p 
        end

    clear activeReach
    end % for i=1:size(reachNames,1)
clear i

% write the slope of DC-I-I in the file as the downstream boundary condition
	fprintf(fid, '%s\n', ['Boundary for River Rch & Prof#=' streamName ',DC-I-1, 1']);
    fprintf(fid, '%s\n', 'Up Type= 0');
    fprintf(fid, '%s\n', 'Dn Type= 3');
    fprintf(fid, '%s\n', ['Dn Slope=' mat2str(downstreamBC)]);
    fprintf(fid, '\n'); % empty row for better legibility
    
% write observed water surface elevation for each cross-section that has ineffective field
    for i=1:size(reachNames,1)
    % find active canal
    activeReach = Model.(reachNames{i}).name;
        if strcmp(activeReach,'DC-IV-1')==1
            % active reach is a lateral drain, data isn't used for it
        else
            reach = activeReach;
            namesXS = fieldnames(Model.(reachNames{i})); % extract cross-section names in active Reach
            [p, ~] = size(namesXS); % returns the number of cross-sections (+1)
            for j=1:p % from 1 to p cross-sections in a reach
                activeXSname = cell2mat(namesXS(j,1)); % active reach name
                if strcmp(activeXSname(1:2), 'P_')==1 && size(namesXS{j},2)==6 % active cross-section is really a cross-section, not metadata
                    station = mat2str(Model.(reachNames{i}).(activeXSname).station); % extracts the station from the cross-section name
                    % check if current cross-section has a water surface elevation assigned
                    if isfield(Model.(reachNames{i}).(activeXSname),'HECobserved')==1
                        OBS = Model.(reachNames{i}).(activeXSname).HECobserved;
                        % enter the part of the string that refers to the water surface elevation
                        fprintf(fid, '%s\n', ['Observed WS=' streamName ',' reach ',' station ',0,' mat2str(OBS)]);
                    else
                    end
                    clear OBS                 
                else
                    % not a cross-section but the inscription of the Reach, do not write anything
                end % if strcmp(activeXSname(1:2), 'P_')==1 && size(namesXS{j},2)==6

                clear station activeXSname
            end % for j=1:p % from 1 to p cross-sections in a reach
       
        clear reach namesXS j p 
        end % if strcmp(activeReach,'MK-IV-1')==1

    clear activeReach
    end % for i=1:size(reachNames,1)
clear i

fclose(fid);
clear fid downstreamBC
msgbox('Finished!', 'Notification')

end
