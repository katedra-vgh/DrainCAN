function outletPT = drainageCanalOutlet(PToutletIII, startPoint, endPoint, tolerance)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function calculates the distance from the tertiary canal outlet
% point (PToutletIII) to the secundary canal axis which is defined by the series
% of points
% If the tertiary canals inflows into the secondary, function returns the
% outflow coordinated, otherwise returns NaN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% find the distance from the DC-III outlet to the starting point of the secondary canal
    distanceOutletStart = sqrt((startPoint(1,1)-PToutletIII(1,1))^2+(startPoint(1,2)-PToutletIII(1,2))^2);
% find the distance from the DC-III outlet to the ending point of the secondary canal
    distanceOutletEnd = sqrt((endPoint(1,1)-PToutletIII(1,1))^2+(endPoint(1,2)-PToutletIII(1,2))^2);
% find the distance of canal DC-III mouth from the axis of secondary canal
    distanceOutlet2D = point_to_line_distance(PToutletIII, startPoint, endPoint);

% control the position of the outlet
if abs(distanceOutletStart) < tolerance
    % mouth is positioned in the junction on the start of the secondary canal, this is covered by the basic code
    outletPT = NaN;
elseif abs(distanceOutletEnd) < tolerance
    % mouth is positioned in the junction on the start of the secondary canal, this is covered by the basic code
    outletPT = NaN;
elseif abs(distanceOutlet2D) < tolerance && distanceOutletStart >0 && distanceOutletEnd > 0
    % Tertiary canal mouth is positioned on the segment of secondary canal, project point on line
    L1 = [startPoint, 0]; L2 = [endPoint, 0]; P = [PToutletIII, 0]; % add Z coordinate
    projection = pointProjectionOnLine(L1, L2, P);
    % control if the mouth is on line
    Q = [projection{1}(1), projection{1}(2)];
    R = pointWithinLine(startPoint, endPoint, Q, 1);
    if R == 1
        % projection of the mouth is on the line of the secondary canal
        outletPT = projection;
    else
        % projection of the mouth is not on the line of the secondary canal
        outletPT = NaN;
    end
else
    % the mouth of the tertiary canal is somewhere far 
    outletPT = NaN;
end