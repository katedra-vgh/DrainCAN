function [value] = stringDoubleCheck(answer, name)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function double-checks if the flow data is entered correcty in the
% .xls file.
% .xls cell values are checked for common errors - multiple decimal spaces,
% numbers stored as text values, etc. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isempty(answer)
% field has no assigned value
    waitfor(msgbox(['Field has no assigned value (' name '). Terminating function!'], 'Notification','Warn'));
    return % leave code
elseif isempty(strfind(answer,','))==0 && isempty(strfind(answer,'.'))==0
% both comma and point are used as decimal separator
    waitfor(msgbox(['Two decimal separators are entered in the .xls cell (' name '). Terminating function!'], 'Notification','Warn'));
    return
elseif isempty(strfind(answer,','))==0
% comma is used as decimal separator
    numberDec = strfind(answer,',');
    numberLeft = str2double(answer(1:numberDec-1));
    numberRight = str2double(answer(numberDec+1:size(answer,2)));
    if isnan(numberLeft) == 1 || isnan(numberRight)==1
        % text
        msgbox(['Value is entered as text instead of number in the .xls cell (' name '). Terminating function!'], 'Notification');
        return
    elseif size(strfind(answer,','),2)>1
        % comma is entered twice
        msgbox(['Two decimal separators are entered in the .xls cell (' name '). Terminating function!'], 'Notification');
        return
    else    
    end
    % define the value that will be entered in structure
    value = str2double([answer(1:numberDec-1) '.' answer(numberDec+1:size(answer,2))]);
elseif isempty(strfind(answer,'.'))==0
% point is used as decimal separator
    numberDec = strfind(answer,'.');
    numberLeft = str2double(answer(1:numberDec-1));
    numberRight = str2double(answer(numberDec+1:size(answer,2)));
    if isnan(numberLeft) == 1 || isnan(numberRight)==1
        % text
        msgbox(['Value is entered as text instead of number in the .xls cell (' name '). Terminating function!'], 'Notification');
        return
    elseif size(strfind(answer,'.'),2)>1
        % point is entered twice
        msgbox(['Two decimal separators are entered in the .xls cell (' name '). Terminating function!']', 'Notification');
        return
    else    
    end
    % define the value that will be entered in structure
    value = str2double([answer(1:numberDec-1) '.' answer(numberDec+1:size(answer,2))]);
else
% check integer or text 
    if isnan(str2double(answer)) == 1
        % text
        msgbox(['Value is entered as text instead of number in the .xls cell (' name '). Terminating function!'], 'Notification');
        return
    else
        % integer
        value = str2double(answer);
    end    
end
end

