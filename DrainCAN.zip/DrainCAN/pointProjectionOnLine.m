function vargout = pointProjectionOnLine(lineStart, lineEnd, pointP)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function determines the projection of the point P to a line segment
% defined by points lineStart and lineEnd
% line is set with two points: start L1 = [X1 Y1 Z1] and end L2 = [X2 Y2 Z2]
% point P is set away from the line
% task is to find the projection of point P on line - named Q
% output variables are coorinates of the point Q and its distance from the
% line endpoints
%
% Function was created by modifying the code distance_point_segment.py
% found on GitHub (https://gist.github.com/irees/be5e56e7c9b16d78a351) and
% stackoverflow
% (http://stackoverflow.com/questions/849211/shortest-distance-between-a-point-and-a-line-segment)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

X1 = lineStart(1,1); Y1 = lineStart(1,2); % geographic coordinates of the start of the line
X2 = lineEnd(1,1); Y2 = lineEnd(1,2); % geographic coordinates of the end of the line
EP = pointP(1,1); NP = pointP(1,2); % geographic coordinates of point P

K = [X2-X1, Y2-Y1; Y1-Y2, X2-X1];
R = -1*[(-EP*(X2-X1)-NP*(Y2-Y1)); (-Y1*(X2-X1)+X1*(Y2-Y1))];

D = inv(K)*R;
ptQ = [D(1),D(2),0]; % geographic coordinates of point Q (projection of point P on line)

L1Q = lineStart-ptQ; % vector between points L1 and Q
L2Q = lineEnd-ptQ; % vector between points L2 and Q

distQL1 = sqrt(L1Q(1,1)^2+L1Q(1,2)^2+L1Q(1,3)^2); % vector distance between points L1 and Q
distQL2 = sqrt(L2Q(1,1)^2+L2Q(1,2)^2+L2Q(1,3)^2); % vector distance between points L2 and Q


%% CHECK IF POINT LIES ON THE LINE
    
% define start and end point
    A = lineStart;
    B = lineEnd;
% vector from A to B
    AB = (B-A);
% vector from A to Q
    AQ = (ptQ-A);
% squared distance from A to B
    AB_squared = dot(AB,AB);
  
    % from http://stackoverflow.com/questions/849211/
    % Consider the line extending the segment, parameterized as A + t (B - A)
    % We find projection of point P onto the line (as Q).
    % It falls where t = [(Q-A) . (B-A)] / |B-A|^2
    t = dot(AQ,AB)/AB_squared;
    if (t < 0.0)
      % "Before" A on the line, return negative value
      distQL1 = -1*distQL1;
    elseif (t > 1.0)
      % "After" B on the line, return negative value
      distQL2 = -1*distQL2;
    else
      % projection lines "inbetween" A and B on the line
      dist = A + t * AB;
    end

%% OUTPUT VARIABLES

vargout{1} = ptQ;
vargout{2} = distQL1;
vargout{3} = distQL2;
